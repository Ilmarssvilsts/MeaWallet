package com.example.meawalletlibrary;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.example.meawallet_security.Encryption;
import com.example.meawalletlibrary.utils.Utils;

import java.util.Arrays;
import java.util.regex.Pattern;

public class MainActivity extends AppCompatActivity {

    EditText inputData;
    EditText inputPassword;
    TextView result;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        inputData = (EditText) findViewById(R.id.data_input);
        inputPassword = (EditText) findViewById(R.id.password_input);
        result = (TextView) findViewById(R.id.result);
    }

    //Main task
    public void EncryptData(View view) {
        String[] data = inputData.getText().toString().split("");
        String[] password = inputPassword.getText().toString().split("");

        Encryption encryptionObject = new Encryption();
        encryptionObject.setup();
        if (linearIn(encryptionObject.column, data) && linearIn(encryptionObject.row, password)) {
            String encryptedResult = encryptionObject.encryptData(inputData.getText().toString(), inputPassword.getText().toString());
            if (encryptedResult != "") {
                result.setText(encryptedResult);
            }
        } else if (data.length == 0 || password.length == 0) {
            Utils.showErrorPopUp(getString(R.string.error), getString(R.string.data_length), view.getContext());
        } else {
            Utils.showErrorPopUp(getString(R.string.unsupported_characters), getString(R.string.new_data), view.getContext());
        }
    }

    //Second bonus task
    public void EncryptData2(View view) {
        String[] data = inputData.getText().toString().split("");
        String[] password = inputPassword.getText().toString().split("");
        Encryption encryptionObject = new Encryption();

        boolean dataValid = Pattern.compile("[^A-Za-z0-9]").matcher(inputData.getText().toString()).find();
        boolean passwordValid = Pattern.compile("[^A-Za-z0-9]").matcher(inputPassword.getText().toString()).find();


        if (data.length == 0 || password.length == 0) {
            Utils.showErrorPopUp(getString(R.string.error), getString(R.string.data_length), view.getContext());
        } else if (!dataValid && !passwordValid) {
            String encryptedResult = encryptionObject.encryptDataTask2(inputData.getText().toString(), inputPassword.getText().toString());
            if (encryptedResult != "") {
                result.setText(encryptedResult);
            }
        } else {
            Utils.showErrorPopUp(getString(R.string.unsupported_characters), getString(R.string.new_data), view.getContext());
        }
    }

    public static boolean linearIn(String[] outer, String[] inner) {
        return Arrays.asList(outer).containsAll(Arrays.asList(inner));
    }
}