package com.example.meawalletlibrary.utils;

import android.content.Context;

import androidx.appcompat.app.AlertDialog;

public class Utils {

    public static void showErrorPopUp(String title, String text, Context context) {
        new AlertDialog.Builder(context)
                .setTitle(title)
                .setMessage(text)
                .setPositiveButton(android.R.string.ok, null)
                .setIcon(android.R.drawable.ic_dialog_alert)
                .show();
    }
}
