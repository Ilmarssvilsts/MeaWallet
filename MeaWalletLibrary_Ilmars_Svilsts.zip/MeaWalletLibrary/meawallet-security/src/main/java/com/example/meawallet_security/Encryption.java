package com.example.meawallet_security;

import android.text.TextUtils;
import android.util.Log;

import java.util.Arrays;
import java.util.regex.Pattern;

public class Encryption {

    public String[] column = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};
    public String[] row = {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0"};

    String[][] encryptionTable = new String[column.length + 1][row.length + 1];

    //todo if encryptionTable is not initialized, then encryptedData table should be used.
    String[][] encryptedData = {{"", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"},
            {"1", "2", "3", "4", "5", "6", "7", "8", "9", "0", "1"},
            {"2", "3", "4", "5", "6", "7", "8", "9", "0", "1", "2"},
            {"3", "4", "5", "6", "7", "8", "9", "0", "1", "2", "3"},
            {"4", "5", "6", "7", "8", "9", "0", "1", "2", "3", "4"},
            {"5", "6", "7", "8", "9", "0", "1", "2", "3", "4", "5"},
            {"6", "7", "8", "9", "0", "1", "2", "3", "4", "5", "6"},
            {"7", "8", "9", "0", "1", "2", "3", "4", "5", "6", "7"},
            {"8", "9", "0", "1", "2", "3", "4", "5", "6", "7", "8"},
            {"9", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9"},
            {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"}};

    public String[] smallLetters = {"a", "b", "c", "d", "e", "f", "g", "h", "i", "j", "k", "l", "m", "n", "o", "p", "q", "r", "s", "t", "u", "v", "w", "x", "y", "z"};
    public String[] bigLetters = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"};

    //Generating Encryption table
    public void setup() {
        String test = "Data\n";
        for (int i = 0; i <= column.length; i++) {
            for (int j = 0; j <= row.length; j++) {
                if (i == 0) {
                    if (j == 0) {
                        encryptionTable[i][j] = "";
                    } else {
                        //index will not be negative, because of the upper if
                        encryptionTable[i][j] = column[j - 1];
                    }
                } else {
                    if (j == 0) {
                        encryptionTable[i][j] = row[i - 1];
                    } else {
                        encryptionTable[i][j] = String.valueOf((Integer.parseInt(column[j - 1]) + Integer.parseInt(row[i - 1])) % 10);
                    }
                }
                test += encryptionTable[i][j];
            }
            test += "\n";
        }
    }

    //validate array if it contains correct data and password numbers or letters
    public static boolean linearIn(String[] outer, String[] inner) {

        return Arrays.asList(outer).containsAll(Arrays.asList(inner));
    }

    //if password or data is too short, add necessary digits to arrays
    public String[] validateInputData(String data, String password, String[] validationArray) {
        String[] dataArray = data.split("");
        if (!linearIn(validationArray, dataArray)) {
            return null;
        } else {
            if (data.length() == 0 || password.length() == 0) {
                return null;
            } else if (password.length() > data.length()) {
                String result = data;
                while (password.length() > result.length()) {
                    for (int i = 0; i < dataArray.length; i++) {
                        if (result.length() == password.length()) break;
                        result += dataArray[i];
                    }
                }
                return result.split("");
            }
        }
        return dataArray;
    }

    //Encrypt recieved data
    public String encryptData(String data, String password) {

        String result = "";
        //Received data and password validation
        String[] dataArray = validateInputData(data, password, column);
        if (dataArray == null || dataArray.length == 0) return "";

        String[] passwordArray = validateInputData(password, data, row);
        if (passwordArray == null || passwordArray.length == 0) return "";

        //Encrypting data
        if (dataArray.length == passwordArray.length) {
            for (int x = 0; x < dataArray.length; x++) {
                int colIndex = 0;
                int rowIndex = 0;
                for (int i = 1; i < encryptionTable.length; i++) {
                    if (encryptionTable[i][0].equals(dataArray[x])) {
                        colIndex = i;
                    }
                    if (encryptionTable[0][i].equals(passwordArray[x])) {
                        rowIndex = i;
                    }
                }
                if (colIndex == 0 || rowIndex == 0) {
                    //data was unsupported
                    return "";
                }
                result += encryptionTable[colIndex][rowIndex];
            }
        }
        return result;
    }

    //Bonus Task 1
    //Use this method instead of "encryptData" to have bonus task 1
    public String encryptDataTask1(String data, String password) {

        String result = "";
        //Received data and password validation
        String[] dataArray = validateInputData(data, password, column);
        if (dataArray == null || dataArray.length == 0) return "";

        String[] passwordArray = validateInputData(password, data, row);
        if (passwordArray == null || passwordArray.length == 0) return "";

        //Encrypting data
        if (dataArray.length == passwordArray.length) {
            for (int x = 0; x < dataArray.length; x++) {
                result += String.valueOf((Integer.parseInt(dataArray[x]) + Integer.parseInt(passwordArray[x])) % 10);
            }
        }
        return result;
    }

    //Bonus Task 2

    //Task does not have any instructions, how support for letters should work. This is my take on this support.
    //Data string is main string and this data is more important then password data. For decryption to be possible, decryption function gets password and result data, function does not see input data.
    //This means - if data=1 and password=1 then result=2 | if data=1 and password=a then result=1 | if data=a and password=1 then result=a | if data = f and password=k then result p

    //Use this method instead of "encryptData" to have bonus task 2
    public String encryptDataTask2(String data, String password) {

        String result = "";
        //Received data and password validation
        String[] dataArray = validateInputData2(data, password);
        if (dataArray == null || dataArray.length == 0) return "";

        String[] passwordArray = validateInputData2(password, data);
        if (passwordArray == null || passwordArray.length == 0) return "";

        //Encrypting data
        if (dataArray.length == passwordArray.length) {
            for (int x = 0; x < dataArray.length; x++) {

                //two numbers
                if (TextUtils.isDigitsOnly(dataArray[x]) && TextUtils.isDigitsOnly(passwordArray[x])) {
                    result += String.valueOf((Integer.parseInt(dataArray[x]) + Integer.parseInt(passwordArray[x])) % 10);
                }
                //number and letter
                else if (TextUtils.isDigitsOnly(dataArray[x])) {
                    result += dataArray[x];
                }
                //letter and number
                else if (TextUtils.isDigitsOnly(passwordArray[x])) {
                    result += dataArray[x];
                }
                //two letters
                else {
                    boolean dataIsSmall = true;
                    int dataIndex = 0;
                    boolean passwordIsSmall = true;
                    int passwordIndex = 0;

                    for (int i = 0; i < smallLetters.length; i++) {
                        if (smallLetters[i].equals(dataArray[x])) {
                            dataIsSmall = true;
                            dataIndex = i;
                        } else if (bigLetters[i].equals(dataArray[x])) {
                            dataIsSmall = false;
                            dataIndex = i;
                        }
                        if (smallLetters[i].equals(passwordArray[x])) {
                            passwordIsSmall = true;
                            passwordIndex = i;
                        } else if (bigLetters[i].equals(passwordArray[x])) {
                            passwordIsSmall = false;
                            passwordIndex = i;
                        }
                    }

                    if (dataIsSmall && passwordIsSmall) {
                        int count = (dataIndex + passwordIndex) % 26;
                        result += smallLetters[count];
                    } else if (!dataIsSmall && !passwordIsSmall) {
                        int count = (dataIndex + passwordIndex) % 26;
                        result += bigLetters[count];
                    } else {
                        result += dataArray[x];
                    }
                }
            }
        }

        //Uncomment if you  want to test bonus task 3(decryption)
        //decryption(passwordArray, result);
        return result;
    }

    //todo Validation functions probably should be rewritten, because some of the code is duplicating.
    public String[] validateInputData2(String data, String password) {
        String[] dataArray = data.split("");
        boolean dataValid = Pattern.compile("[^A-Za-z0-9]").matcher(data).find();

        if (dataValid) {
            return null;
        } else {
            if (data.length() == 0 || password.length() == 0) {
                return null;
            } else if (password.length() > data.length()) {
                String result = data;
                while (password.length() > result.length()) {
                    for (int i = 0; i < dataArray.length; i++) {
                        if (result.length() == password.length()) break;
                        result += dataArray[i];
                    }
                }
                return result.split("");
            }
        }
        return dataArray;
    }

    //Bonus task 3
    //todo function should have size of input data as well, otherwise if password is bigger we get validated data.
    public String decryption(String[] password, String result) {
        String decryptionResult = "";
        String[] resultArray = result.split("");

        for (int x = 0; x < resultArray.length; x++) {

            //two numbers
            if (TextUtils.isDigitsOnly(resultArray[x]) && TextUtils.isDigitsOnly(password[x])) {
                int res = Integer.parseInt(resultArray[x]) - Integer.parseInt(password[x]);
                if (res < 0) {
                    res += 10;
                }
                decryptionResult += String.valueOf(res);
            }
            //number and letter
            else if (TextUtils.isDigitsOnly(resultArray[x])) {
                decryptionResult += resultArray[x];
            }
            //letter and number
            else if (TextUtils.isDigitsOnly(password[x])) {
                decryptionResult += resultArray[x];
            }
            //two letters
            else {
                boolean resultIsSmall = true;
                int resultIndex = 0;
                boolean passwordIsSmall = true;
                int passwordIndex = 0;

                for (int i = 0; i < smallLetters.length; i++) {
                    if (smallLetters[i].equals(resultArray[x])) {
                        resultIsSmall = true;
                        resultIndex = i;
                    } else if (bigLetters[i].equals(resultArray[x])) {
                        resultIsSmall = false;
                        resultIndex = i;
                    }
                    if (smallLetters[i].equals(password[x])) {
                        passwordIsSmall = true;
                        passwordIndex = i;
                    } else if (bigLetters[i].equals(password[x])) {
                        passwordIsSmall = false;
                        passwordIndex = i;
                    }
                }

                if (resultIsSmall && passwordIsSmall) {
                    int count = resultIndex - passwordIndex;
                    if (count < 0) {
                        count += 26;
                    }
                    decryptionResult += smallLetters[count];
                } else if (!resultIsSmall && !passwordIsSmall) {
                    int count = resultIndex - passwordIndex;
                    if (count < 0) {
                        count += 26;
                    }
                    decryptionResult += bigLetters[count];
                } else {
                    decryptionResult += resultArray[x];
                }
            }
        }

        Log.d("decryptedResult", decryptionResult);
        return decryptionResult;
    }
}
