package com.example.meawallet_security;

import org.junit.Test;

import static org.junit.Assert.*;

public class EncryptionUnitTests {

    @Test
    public void input_data_validation_isCorrect() {
        Encryption encryptionObject = new Encryption();
        encryptionObject.setup();
        String data = "123";
        String password = "123";
        String[] result = encryptionObject.validateInputData(data, password, encryptionObject.column);
        String[] expected = {"1", "2", "3"};
        assertArrayEquals("Equal size data and password array did not get validated!", expected, result);

        data = "123";
        password = "123456";
        result = encryptionObject.validateInputData(data, password, encryptionObject.column);
        expected = new String[]{"1", "2", "3", "1", "2", "3"};
        assertArrayEquals("Smaller size data and bigger password array did not get validated!", expected, result);

        data = "123456";
        password = "123";
        result = encryptionObject.validateInputData(data, password, encryptionObject.column);
        expected = new String[]{"1", "2", "3", "4", "5", "6"};
        assertArrayEquals("Bigger size data and smaller password array did not get validated!", expected, result);

        data = "a";
        password = "123";
        result = encryptionObject.validateInputData(data, password, encryptionObject.column);
        expected = null;
        assertArrayEquals("Letter in data array did get validated!", expected, result);

        data = "123 4";
        password = "123; ";
        result = encryptionObject.validateInputData(data, password, encryptionObject.column);
        expected = null;
        assertArrayEquals("Symbols in data array did get validated!", expected, result);
    }

    @Test
    public void input_data_validation_2_isCorrect() {
        Encryption encryptionObject = new Encryption();
        encryptionObject.setup();
        String data = "123";
        String password = "123";
        String[] result = encryptionObject.validateInputData2(data, password);
        String[] expected = {"1", "2", "3"};
        assertArrayEquals("Equal size data and password array did not get validated!", expected, result);

        data = "123";
        password = "123456";
        result = encryptionObject.validateInputData2(data, password);
        expected = new String[]{"1", "2", "3", "1", "2", "3"};
        assertArrayEquals("Smaller size data and bigger password array did not get validated!", expected, result);

        data = "123456";
        password = "123";
        result = encryptionObject.validateInputData2(data, password);
        expected = new String[]{"1", "2", "3", "4", "5", "6"};
        assertArrayEquals("Bigger size data and smaller password array did not get validated!", expected, result);

        data = "aZ";
        password = "123";
        result = encryptionObject.validateInputData2(data, password);
        expected = new String[]{"a", "Z", "a"};
        assertArrayEquals("Letter in data array did not get validated!", expected, result);
    }

    @Test
    public void encrypt_data_isCorrect() {
        Encryption encryptionObject = new Encryption();
        encryptionObject.setup();
        String data = "123";
        String password = "123";
        String result = encryptionObject.encryptData(data, password);
        String expected = "246";
        assertEquals("Equal size data and password array did not get encrypted!", expected, result);

        data = "123";
        password = "123456";
        result = encryptionObject.encryptData(data, password);
        expected = "246579";
        assertEquals("Smaller size data and bigger password array did not get encrypted!", expected, result);

        data = "123456";
        password = "123";
        result = encryptionObject.encryptData(data, password);
        expected = "246579";
        assertEquals("Bigger size data and smaller password array did not get encrypted!", expected, result);

        data = "aZ";
        password = "123";
        result = encryptionObject.encryptData(data, password);
        expected = "";
        assertEquals("Letter in data array did get encrypted!", expected, result);
    }

    @Test
    public void encrypt_data_task_1_isCorrect() {
        Encryption encryptionObject = new Encryption();
        encryptionObject.setup();
        String data = "123";
        String password = "123";
        String result = encryptionObject.encryptDataTask1(data, password);
        String expected = "246";
        assertEquals("Equal size data and password array did not get encrypted!", expected, result);

        data = "123";
        password = "123456";
        result = encryptionObject.encryptDataTask1(data, password);
        expected = "246579";
        assertEquals("Smaller size data and bigger password array did not get encrypted!", expected, result);

        data = "123456";
        password = "123";
        result = encryptionObject.encryptDataTask1(data, password);
        expected = "246579";
        assertEquals("Bigger size data and smaller password array did not get encrypted!", expected, result);

        data = "aZ";
        password = "123";
        result = encryptionObject.encryptDataTask1(data, password);
        expected = "";
        assertEquals("Letter in data array did not get encrypted!", expected, result);
    }


    @Test
    public void encrypt_data_task_2_isCorrect() {
        //todo because of TextUtils class used in library(isDigitsOnly method), we need to mock it
    }

    @Test
    public void decrypting_isCorrect() {
        //todo because of TextUtils class used in library(isDigitsOnly method), we need to mock it
    }
}
